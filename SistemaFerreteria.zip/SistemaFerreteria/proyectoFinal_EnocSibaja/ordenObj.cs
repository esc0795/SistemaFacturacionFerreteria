﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectoFinal_EnocSibaja
{
    class ordenObj
    {
        public string codigo { get; set; }
        public string cantidad { get; set; }
        public DateTime fecha { get; set; }
    }
}
