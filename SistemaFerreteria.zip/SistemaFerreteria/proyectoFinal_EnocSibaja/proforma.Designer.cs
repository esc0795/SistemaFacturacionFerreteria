﻿
namespace proyectoFinal_EnocSibaja
{
    partial class proforma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cliente = new System.Windows.Forms.TextBox();
            this.correo = new System.Windows.Forms.TextBox();
            this.fecha = new System.Windows.Forms.TextBox();
            this.telefono = new System.Windows.Forms.TextBox();
            this.numFac = new System.Windows.Forms.TextBox();
            this.subtotal = new System.Windows.Forms.TextBox();
            this.impuestos = new System.Windows.Forms.TextBox();
            this.total = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lvFac = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(48, 85);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(64, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cliente: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(48, 135);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label3.Size = new System.Drawing.Size(63, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Correo: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(310, 135);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(78, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Telefono: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(284, 32);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(148, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Numero de Factura: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(329, 85);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(59, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Fecha: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(27, 187);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(251, 22);
            this.label7.TabIndex = 7;
            this.label7.Text = "DETALLE DE FACTURACION";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(310, 474);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label8.Size = new System.Drawing.Size(73, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Subtotal: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(300, 508);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label9.Size = new System.Drawing.Size(83, 16);
            this.label9.TabIndex = 9;
            this.label9.Text = "Impuestos:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(335, 539);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(48, 16);
            this.label10.TabIndex = 10;
            this.label10.Text = "Total:";
            // 
            // cliente
            // 
            this.cliente.BackColor = System.Drawing.SystemColors.Control;
            this.cliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cliente.CausesValidation = false;
            this.cliente.Location = new System.Drawing.Point(108, 87);
            this.cliente.Name = "cliente";
            this.cliente.ReadOnly = true;
            this.cliente.Size = new System.Drawing.Size(158, 13);
            this.cliente.TabIndex = 11;
            // 
            // correo
            // 
            this.correo.BackColor = System.Drawing.SystemColors.Control;
            this.correo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.correo.CausesValidation = false;
            this.correo.Location = new System.Drawing.Point(108, 137);
            this.correo.Name = "correo";
            this.correo.ReadOnly = true;
            this.correo.Size = new System.Drawing.Size(158, 13);
            this.correo.TabIndex = 12;
            // 
            // fecha
            // 
            this.fecha.BackColor = System.Drawing.SystemColors.Control;
            this.fecha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fecha.CausesValidation = false;
            this.fecha.Location = new System.Drawing.Point(389, 87);
            this.fecha.Name = "fecha";
            this.fecha.ReadOnly = true;
            this.fecha.Size = new System.Drawing.Size(158, 13);
            this.fecha.TabIndex = 13;
            // 
            // telefono
            // 
            this.telefono.BackColor = System.Drawing.SystemColors.Control;
            this.telefono.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.telefono.CausesValidation = false;
            this.telefono.Location = new System.Drawing.Point(394, 138);
            this.telefono.Name = "telefono";
            this.telefono.ReadOnly = true;
            this.telefono.Size = new System.Drawing.Size(158, 13);
            this.telefono.TabIndex = 14;
            // 
            // numFac
            // 
            this.numFac.BackColor = System.Drawing.SystemColors.Control;
            this.numFac.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numFac.Location = new System.Drawing.Point(438, 33);
            this.numFac.Name = "numFac";
            this.numFac.ReadOnly = true;
            this.numFac.Size = new System.Drawing.Size(158, 13);
            this.numFac.TabIndex = 15;
            // 
            // subtotal
            // 
            this.subtotal.BackColor = System.Drawing.SystemColors.Control;
            this.subtotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.subtotal.CausesValidation = false;
            this.subtotal.Location = new System.Drawing.Point(389, 476);
            this.subtotal.Name = "subtotal";
            this.subtotal.ReadOnly = true;
            this.subtotal.Size = new System.Drawing.Size(158, 13);
            this.subtotal.TabIndex = 16;
            // 
            // impuestos
            // 
            this.impuestos.BackColor = System.Drawing.SystemColors.Control;
            this.impuestos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.impuestos.CausesValidation = false;
            this.impuestos.Location = new System.Drawing.Point(389, 510);
            this.impuestos.Name = "impuestos";
            this.impuestos.ReadOnly = true;
            this.impuestos.Size = new System.Drawing.Size(158, 13);
            this.impuestos.TabIndex = 17;
            // 
            // total
            // 
            this.total.BackColor = System.Drawing.SystemColors.Control;
            this.total.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.total.CausesValidation = false;
            this.total.Location = new System.Drawing.Point(389, 541);
            this.total.Name = "total";
            this.total.ReadOnly = true;
            this.total.Size = new System.Drawing.Size(158, 13);
            this.total.TabIndex = 18;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::proyectoFinal_EnocSibaja.Properties.Resources.epa;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(31, 474);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(235, 87);
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // lvFac
            // 
            this.lvFac.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvFac.CausesValidation = false;
            this.lvFac.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvFac.HideSelection = false;
            this.lvFac.Location = new System.Drawing.Point(31, 220);
            this.lvFac.Name = "lvFac";
            this.lvFac.Size = new System.Drawing.Size(549, 234);
            this.lvFac.TabIndex = 21;
            this.lvFac.UseCompatibleStateImageBehavior = false;
            this.lvFac.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Codigo Producto";
            this.columnHeader1.Width = 95;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Cantidad";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 74;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Detalle";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 256;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Precio";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 117;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.CausesValidation = false;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(78, 29);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(94, 22);
            this.label1.TabIndex = 22;
            this.label1.Text = "FACTURA";
            // 
            // proforma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(628, 573);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lvFac);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.total);
            this.Controls.Add(this.impuestos);
            this.Controls.Add(this.subtotal);
            this.Controls.Add(this.numFac);
            this.Controls.Add(this.telefono);
            this.Controls.Add(this.fecha);
            this.Controls.Add(this.correo);
            this.Controls.Add(this.cliente);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "proforma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Factura";
            this.Load += new System.EventHandler(this.proforma_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox cliente;
        private System.Windows.Forms.TextBox correo;
        private System.Windows.Forms.TextBox fecha;
        private System.Windows.Forms.TextBox telefono;
        private System.Windows.Forms.TextBox numFac;
        private System.Windows.Forms.TextBox subtotal;
        private System.Windows.Forms.TextBox impuestos;
        private System.Windows.Forms.TextBox total;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ListView lvFac;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Label label1;
    }
}